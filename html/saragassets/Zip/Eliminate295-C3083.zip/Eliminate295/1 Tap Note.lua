return Def.Sprite {
	Texture="Notes/bar/_White Tap Note";
	Frames=Sprite.LinearFrames(1,20);
};