return Def.Sprite {
	Texture=NOTESKIN:GetPath("", "Rolls/Roll Body" )   
};