return Def.Sprite {
	Texture="Notes/bar/_Blue Tap Note";
	Frames=Sprite.LinearFrames(1,20);
};