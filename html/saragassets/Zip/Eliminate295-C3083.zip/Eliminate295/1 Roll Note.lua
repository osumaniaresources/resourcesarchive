return Def.Sprite {
	Texture="Rolls/Roll Note";
	Frames=Sprite.LinearFrames(1,20);
};