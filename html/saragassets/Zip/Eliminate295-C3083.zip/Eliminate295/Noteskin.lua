--Noteskin based on c r y s t a l l i z e d  available on EO


local Noteskin = ... or {};
local button = Var "Button"

--Column redirs. The way these are set up makes it so EVERYTHING BUT 4K IS NOT SUPPORTED!!!!!!!!
Noteskin.ButtonRedirs = {
	--Dance(4k)
	Left		= "1";
	Down		= "2";
	Up			= "3";
	Right		= "4";
};

--Element redirects
Noteskin.ElementRedirs = {
	--Redirect dim explosion
	["Tap Explosion Dim"] = "Tap Explosion Bright";

	--Redirect mine explosion to tap explosion
	["HitMine Explosion"] = "Tap Explosion Bright";

	--Redirect hold elements
	["Hold Body Inactive"]		= "Hold Body Active";
	--["Hold BottomCap Inactive"]	= "Hold BottomCap Active";

	--Redirect roll elements
	["Roll Body Inactive"]		= "Roll Body Active";
	--["Roll BottomCap Inactive"]	= "Roll BottomCap Active";

	--Redirect mines
	["Tap Mine"]				= "Mine Dot";

	["Hold Head Active"]		= "Tap Note";
	["Hold Head Inactive"]		= "Tap Note";
	["Roll Head Active"]		= "Roll Note";
	["Roll Head Inactive"]		= "Roll Note";
};

--Invisible elements
Noteskin.Hide = {
	["Tap Fake"] 				= true;
	["Tap Lift"] 				= true;
	["Hold Tail Active"]		= true;
	["Hold Tail Inactive"]		= true;
	["Roll Tail Active"]		= true;
	["Roll Tail Inactive"]		= true;
};

--Rotations
Noteskin.BaseRotX = {
	Left	= 0;
	UpLeft	= 0;
	Up		= 0;
	Down	= 0;
	UpRight	= 0;
	Right	= 0;
};
Noteskin.BaseRotY = {
	Left	= 0;
	UpLeft	= 0;
	Up		= 0;
	Down	= 0;
	UpRight	= 0;
	Right	= 0;
};

--This part loads elements but I honestly have no clue how it works
local function NoteskinLoader()
	local Button = Var "Button"
	local Element = Var "Element"

	if Noteskin.Hide[Element] then
		--Return a blank element. If SpriteOnly is set, we need to return a
		--sprite; otherwise just return a dummy actor.
		local t;
		if Var "SpriteOnly" then
			t = LoadActor( "_blank" );
		else
			t = Def.Actor {};
		end
		return t .. {
			InitCommand = function(self)
    			self:visible(false)
  			end
		};
	end;


	--Load element and button, using redirs
	local LoadElement = Noteskin.ElementRedirs[Element]
	if not LoadElement then
		LoadElement = Element;
	end;

	local LoadButton = Noteskin.ButtonRedirs[Button]
	if not LoadButton then
		LoadButton = Button;
	end;

	--Get path to thing
	local sPath = NOTESKIN:GetPath( LoadButton, LoadElement );

	--Make actor
	local t = LoadActor( sPath );

	--Apply rotation
	t.BaseRotationX=Noteskin.BaseRotX[sButton]
	t.BaseRotationY=Noteskin.BaseRotY[sButton]

	return t;
end

Noteskin.Load = NoteskinLoader;
Noteskin.CommonLoad = NoteskinLoader;
return Noteskin;