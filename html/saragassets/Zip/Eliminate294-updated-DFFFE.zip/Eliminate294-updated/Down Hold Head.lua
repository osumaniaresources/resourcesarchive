local t =
	Def.Sprite {
	Texture = NOTESKIN:GetPath("_down", "hold active"),
	Frame0000 = 0,
	Delay0000 = 1
}
return t

